using System;
using System.Collections.Generic;

public static class CircuitTopology
{
    public static Dictionary<string, string> BuildNodeMap(
        IEnumerable<string> terminals,
        IEnumerable<(string from, string to)> wires)
    {
        var parent = new Dictionary<string, string>();

        foreach (string terminal in terminals)
            if (!parent.ContainsKey(terminal))
                parent[terminal] = terminal;

        foreach (var wire in wires)
        {
            if (!parent.ContainsKey(wire.from))
                parent[wire.from] = wire.from;
            if (!parent.ContainsKey(wire.to))
                parent[wire.to] = wire.to;
            Union(parent, wire.from, wire.to);
        }

        var result = new Dictionary<string, string>();
        foreach (string terminal in parent.Keys)
            result[terminal] = Find(parent, terminal);

        return result;
    }

    private static string Find(Dictionary<string, string> parent, string item)
    {
        string p = parent[item];
        if (p != item)
            parent[item] = Find(parent, p);
        return parent[item];
    }

    private static void Union(Dictionary<string, string> parent, string a, string b)
    {
        string rootA = Find(parent, a);
        string rootB = Find(parent, b);
        if (rootA != rootB)
            parent[rootB] = rootA;
    }
}

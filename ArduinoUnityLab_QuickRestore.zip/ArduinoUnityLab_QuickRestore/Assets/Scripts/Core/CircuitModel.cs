using System.Collections.Generic;

public class CircuitModel
{
    public readonly List<CircuitComponent> components = new List<CircuitComponent>();

    public void AddComponent(CircuitComponent component)
    {
        components.Add(component);
    }

    public bool RemoveComponent(string id)
    {
        return components.RemoveAll(c => c.Id == id) > 0;
    }
}

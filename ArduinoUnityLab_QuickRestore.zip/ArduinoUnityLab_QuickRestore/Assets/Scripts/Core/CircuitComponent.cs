using System;

[Serializable]
public class CircuitComponent
{
    public string Id;
    public string Type;
    public string PinA;
    public string PinB;
    public double Value;

    public CircuitComponent(string id, string type, string pinA, string pinB, double value)
    {
        Id = id;
        Type = type;
        PinA = pinA;
        PinB = pinB;
        Value = value;
    }
}

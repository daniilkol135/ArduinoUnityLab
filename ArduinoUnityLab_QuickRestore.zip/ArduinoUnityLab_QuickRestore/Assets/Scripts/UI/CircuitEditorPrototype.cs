using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

public class CircuitEditorPrototype : MonoBehaviour
{
    [Serializable]
    private class ResistorView
    {
        public Vector2 position;
        public double resistance = 1000.0;
        public string id;
    }

    [Serializable]
    private class PowerSupplyView
    {
        public Vector2 position;
        public double voltage = 5.0;
        public string id;
    }

    [Serializable]
    private class WireView
    {
        public string fromId;
        public bool fromRight;
        public string toId;
        public bool toRight;
    }

    private struct TerminalHit
    {
        public bool found;
        public string componentId;
        public bool rightSide;
    }

    private readonly List<ResistorView> resistors = new List<ResistorView>();
    private readonly List<PowerSupplyView> powerSupplies = new List<PowerSupplyView>();
    private readonly List<WireView> wires = new List<WireView>();

    private bool placingResistor;
    private bool placingPowerSupply;
    private bool placingWire;
    private bool hasWireStart;
    private string wireStartId;
    private bool wireStartRight;

    private string selectedComponentId;
    private int selectedWire = -1;
    private bool dragging;
    private Vector2 dragOffset;

    private Texture2D pixel;
    private Rect workspace;
    private string status = "Ready";
    private string parameterText = "";
    private string parameterTextForId;
    private int nextResistorId = 1;
    private int nextPowerSupplyId = 1;

    private const float GridSize = 25f;
    private const float ComponentWidth = 112f;
    private const float ComponentHeight = 58f;
    private const float TerminalHitRadius = 14f;

    private void Awake()
    {
        pixel = new Texture2D(1, 1);
        pixel.SetPixel(0, 0, Color.white);
        pixel.Apply();
    }

    private void OnDestroy()
    {
        if (pixel != null)
            Destroy(pixel);
    }

    private void OnGUI()
    {
        DrawBackground();

        GUI.Box(new Rect(0, 0, Screen.width, 70), "ArduinoUnityLab | Circuit Editor");

        if (GUI.Button(new Rect(10, 32, 105, 26), "+ Resistor"))
        {
            placingResistor = true;
            placingPowerSupply = false;
            placingWire = false;
            hasWireStart = false;
            dragging = false;
            status = "Click the grid to place a resistor";
        }

        if (GUI.Button(new Rect(120, 32, 125, 26), "+ Power Supply"))
        {
            placingPowerSupply = true;
            placingResistor = false;
            placingWire = false;
            hasWireStart = false;
            dragging = false;
            status = "Click the grid to place a 5V power supply";
        }

        if (GUI.Button(new Rect(250, 32, 100, 26), "+ Wire"))
        {
            placingWire = true;
            placingResistor = false;
            placingPowerSupply = false;
            hasWireStart = false;
            dragging = false;
            status = "Click the first terminal";
        }

        if (GUI.Button(new Rect(355, 32, 80, 26), "Delete"))
            DeleteSelection();

        if (GUI.Button(new Rect(440, 32, 95, 26), "Clear all"))
        {
            resistors.Clear();
            powerSupplies.Clear();
            wires.Clear();
            ClearSelection();
            hasWireStart = false;
            placingWire = false;
            placingResistor = false;
            placingPowerSupply = false;
            status = "Workspace cleared";
        }

        workspace = new Rect(12, 78, Screen.width - 24, Screen.height - 114);

        DrawGrid(workspace);
        HandleWorkspaceInput();

        for (int i = 0; i < wires.Count; i++)
            DrawWire(wires[i], i == selectedWire);

        for (int i = 0; i < resistors.Count; i++)
            DrawResistor(resistors[i], resistors[i].id == selectedComponentId);

        for (int i = 0; i < powerSupplies.Count; i++)
            DrawPowerSupply(powerSupplies[i], powerSupplies[i].id == selectedComponentId);

        DrawSelectedComponentEditor();

        GUI.Label(
            new Rect(14, Screen.height - 30, Screen.width - 28, 24),
            status + " | Resistors: " + resistors.Count +
            " | Power supplies: " + powerSupplies.Count +
            " | Wires: " + wires.Count);
    }

    private Rect GetPropertyPanelRect()
    {
        return new Rect(Screen.width - 268f, 84f, 250f, 92f);
    }

    private void DrawSelectedComponentEditor()
    {
        if (string.IsNullOrEmpty(selectedComponentId))
            return;

        ResistorView resistor = resistors.Find(r => r.id == selectedComponentId);
        PowerSupplyView source = powerSupplies.Find(v => v.id == selectedComponentId);
        if (resistor == null && source == null)
            return;

        if (parameterTextForId != selectedComponentId)
        {
            parameterTextForId = selectedComponentId;
            parameterText = resistor != null
                ? resistor.resistance.ToString(CultureInfo.InvariantCulture)
                : source.voltage.ToString(CultureInfo.InvariantCulture);
        }

        Rect panel = GetPropertyPanelRect();
        GUI.Box(panel, "Component properties");
        GUI.Label(new Rect(panel.x + 10f, panel.y + 25f, 90f, 22f),
            resistor != null ? "Resistance (Ω)" : "Voltage (V)");
        parameterText = GUI.TextField(new Rect(panel.x + 105f, panel.y + 25f, 132f, 22f), parameterText);

        if (GUI.Button(new Rect(panel.x + 10f, panel.y + 54f, 227f, 28f), "Apply value"))
        {
            double value;
            if (!double.TryParse(parameterText, NumberStyles.Float, CultureInfo.InvariantCulture, out value))
            {
                status = "Invalid number. Use a dot for decimals, e.g. 2.5";
                return;
            }
            if (value <= 0.0 || double.IsNaN(value) || double.IsInfinity(value))
            {
                status = "Value must be a positive finite number";
                return;
            }

            if (resistor != null)
            {
                resistor.resistance = value;
                status = resistor.id + " resistance set to " + value.ToString("0.###", CultureInfo.InvariantCulture) + " Ω";
            }
            else
            {
                source.voltage = value;
                status = source.id + " voltage set to " + value.ToString("0.###", CultureInfo.InvariantCulture) + " V";
            }
            parameterText = value.ToString(CultureInfo.InvariantCulture);
        }
    }

    private void DrawBackground()
    {
        GUI.color = new Color(0.10f, 0.12f, 0.15f);
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), pixel);
        GUI.color = Color.white;
    }

    private void DrawGrid(Rect area)
    {
        GUI.Box(area, GUIContent.none);
        GUI.BeginGroup(area);
        GUI.color = new Color(0.24f, 0.28f, 0.32f);

        for (float x = 0; x < area.width; x += GridSize)
            GUI.DrawTexture(new Rect(x, 0, 1, area.height), pixel);
        for (float y = 0; y < area.height; y += GridSize)
            GUI.DrawTexture(new Rect(0, y, area.width, 1), pixel);

        GUI.color = Color.white;
        GUI.EndGroup();
    }

    private void HandleWorkspaceInput()
    {
        Event e = Event.current;
        Vector2 mouse = e.mousePosition;

        // Let the property controls receive clicks instead of treating them as workspace input.
        if (e.type == EventType.MouseDown && GetPropertyPanelRect().Contains(mouse))
            return;

        if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape)
        {
            placingResistor = false;
            placingPowerSupply = false;
            placingWire = false;
            hasWireStart = false;
            dragging = false;
            status = "Action cancelled";
            e.Use();
            return;
        }

        if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Delete)
        {
            DeleteSelection();
            e.Use();
            return;
        }

        if (e.type == EventType.MouseDown && e.button == 0 && workspace.Contains(mouse))
        {
            Vector2 point = mouse - workspace.position;

            if (placingResistor)
            {
                resistors.Add(new ResistorView
                {
                    position = Snap(point),
                    resistance = 1000.0,
                    id = "R" + nextResistorId++
                });
                selectedComponentId = resistors[resistors.Count - 1].id;
                selectedWire = -1;
                placingResistor = false;
                status = "Resistor placed";
                e.Use();
                return;
            }

            if (placingPowerSupply)
            {
                powerSupplies.Add(new PowerSupplyView
                {
                    position = Snap(point),
                    voltage = 5.0,
                    id = "V" + nextPowerSupplyId++
                });
                selectedComponentId = powerSupplies[powerSupplies.Count - 1].id;
                selectedWire = -1;
                placingPowerSupply = false;
                status = "5V power supply placed; left terminal is -, right terminal is +";
                e.Use();
                return;
            }

            if (placingWire)
            {
                TerminalHit hit = FindTerminal(point);
                if (!hit.found)
                {
                    status = "Click a terminal on a component";
                    e.Use();
                    return;
                }

                if (!hasWireStart)
                {
                    wireStartId = hit.componentId;
                    wireStartRight = hit.rightSide;
                    hasWireStart = true;
                    status = "Now click the destination terminal";
                    e.Use();
                    return;
                }

                if (wireStartId == hit.componentId && wireStartRight == hit.rightSide)
                {
                    status = "Choose a different terminal";
                    e.Use();
                    return;
                }

                wires.Add(new WireView
                {
                    fromId = wireStartId,
                    fromRight = wireStartRight,
                    toId = hit.componentId,
                    toRight = hit.rightSide
                });

                hasWireStart = false;
                placingWire = false;
                selectedWire = wires.Count - 1;
                selectedComponentId = null;
                status = "Wire connected";
                e.Use();
                return;
            }

            TerminalHit terminal = FindTerminal(point);
            if (terminal.found)
            {
                selectedComponentId = terminal.componentId;
                selectedWire = -1;
                dragging = true;
                Vector2 componentPosition;
                if (TryGetComponentPosition(selectedComponentId, out componentPosition))
                {
                    dragOffset = componentPosition - point;
                    status = "Dragging " + selectedComponentId;
                }
                e.Use();
                return;
            }

            int wireIndex = FindWire(point);
            if (wireIndex >= 0)
            {
                selectedWire = wireIndex;
                selectedComponentId = null;
                dragging = false;
                status = "Wire selected";
                e.Use();
                return;
            }

            selectedComponentId = FindComponent(point);
            selectedWire = -1;
            Vector2 selectedPosition;
            if (selectedComponentId != null && TryGetComponentPosition(selectedComponentId, out selectedPosition))
            {
                dragging = true;
                dragOffset = selectedPosition - point;
                status = "Dragging " + selectedComponentId;
            }
            else
            {
                dragging = false;
                status = "Nothing selected";
            }
            e.Use();
        }

        if (e.type == EventType.MouseDrag && e.button == 0 && dragging && selectedComponentId != null)
        {
            Vector2 point = mouse - workspace.position;
            SetComponentPosition(selectedComponentId, Snap(point + dragOffset));
            e.Use();
        }

        if (e.type == EventType.MouseUp && dragging)
        {
            dragging = false;
            status = "Ready";
            e.Use();
        }
    }

    private TerminalHit FindTerminal(Vector2 point)
    {
        for (int i = powerSupplies.Count - 1; i >= 0; i--)
        {
            PowerSupplyView source = powerSupplies[i];
            Vector2 left = source.position + new Vector2(-ComponentWidth / 2f, 0);
            Vector2 right = source.position + new Vector2(ComponentWidth / 2f, 0);
            if (Vector2.Distance(point, left) <= TerminalHitRadius)
                return new TerminalHit { found = true, componentId = source.id, rightSide = false };
            if (Vector2.Distance(point, right) <= TerminalHitRadius)
                return new TerminalHit { found = true, componentId = source.id, rightSide = true };
        }

        for (int i = resistors.Count - 1; i >= 0; i--)
        {
            ResistorView resistor = resistors[i];
            Vector2 left = resistor.position + new Vector2(-ComponentWidth / 2f, 0);
            Vector2 right = resistor.position + new Vector2(ComponentWidth / 2f, 0);
            if (Vector2.Distance(point, left) <= TerminalHitRadius)
                return new TerminalHit { found = true, componentId = resistor.id, rightSide = false };
            if (Vector2.Distance(point, right) <= TerminalHitRadius)
                return new TerminalHit { found = true, componentId = resistor.id, rightSide = true };
        }

        return new TerminalHit { found = false, componentId = null, rightSide = false };
    }

    private Vector2 GetTerminalPosition(string componentId, bool rightSide)
    {
        Vector2 position;
        if (!TryGetComponentPosition(componentId, out position))
            return Vector2.zero;

        float offset = rightSide ? ComponentWidth / 2f : -ComponentWidth / 2f;
        return position + new Vector2(offset, 0);
    }

    private bool TryGetComponentPosition(string id, out Vector2 position)
    {
        int resistorIndex = resistors.FindIndex(r => r.id == id);
        if (resistorIndex >= 0)
        {
            position = resistors[resistorIndex].position;
            return true;
        }

        int sourceIndex = powerSupplies.FindIndex(v => v.id == id);
        if (sourceIndex >= 0)
        {
            position = powerSupplies[sourceIndex].position;
            return true;
        }

        position = Vector2.zero;
        return false;
    }

    private void SetComponentPosition(string id, Vector2 position)
    {
        int resistorIndex = resistors.FindIndex(r => r.id == id);
        if (resistorIndex >= 0)
        {
            resistors[resistorIndex].position = position;
            return;
        }

        int sourceIndex = powerSupplies.FindIndex(v => v.id == id);
        if (sourceIndex >= 0)
            powerSupplies[sourceIndex].position = position;
    }

    private string FindComponent(Vector2 point)
    {
        for (int i = powerSupplies.Count - 1; i >= 0; i--)
        {
            Vector2 p = powerSupplies[i].position;
            if (new Rect(p.x - ComponentWidth / 2f, p.y - ComponentHeight / 2f, ComponentWidth, ComponentHeight).Contains(point))
                return powerSupplies[i].id;
        }

        for (int i = resistors.Count - 1; i >= 0; i--)
        {
            Vector2 p = resistors[i].position;
            if (new Rect(p.x - ComponentWidth / 2f, p.y - ComponentHeight / 2f, ComponentWidth, ComponentHeight).Contains(point))
                return resistors[i].id;
        }

        return null;
    }

    private int FindWire(Vector2 point)
    {
        for (int i = wires.Count - 1; i >= 0; i--)
        {
            Vector2 a = GetTerminalPosition(wires[i].fromId, wires[i].fromRight);
            Vector2 b = GetTerminalPosition(wires[i].toId, wires[i].toRight);
            if (DistanceToSegment(point, a, b) < 9f)
                return i;
        }
        return -1;
    }

    private float DistanceToSegment(Vector2 point, Vector2 a, Vector2 b)
    {
        Vector2 ab = b - a;
        float lengthSquared = ab.sqrMagnitude;
        if (lengthSquared < 0.001f)
            return Vector2.Distance(point, a);
        float t = Mathf.Clamp01(Vector2.Dot(point - a, ab) / lengthSquared);
        return Vector2.Distance(point, a + t * ab);
    }

    private Vector2 Snap(Vector2 position)
    {
        return new Vector2(
            Mathf.Round(position.x / GridSize) * GridSize,
            Mathf.Round(position.y / GridSize) * GridSize);
    }

    private void DrawWire(WireView wire, bool isSelected)
    {
        Vector2 a = workspace.position + GetTerminalPosition(wire.fromId, wire.fromRight);
        Vector2 b = workspace.position + GetTerminalPosition(wire.toId, wire.toRight);
        Color color = isSelected ? new Color(1f, 0.75f, 0.2f) : new Color(0.25f, 0.85f, 0.95f);
        DrawLine(a, b, color, isSelected ? 4f : 3f);
    }

    private void DrawLine(Vector2 start, Vector2 end, Color color, float thickness)
    {
        float distance = Vector2.Distance(start, end);
        int steps = Mathf.Max(1, Mathf.CeilToInt(distance / 3f));
        GUI.color = color;
        for (int i = 0; i <= steps; i++)
        {
            Vector2 p = Vector2.Lerp(start, end, i / (float)steps);
            GUI.DrawTexture(new Rect(p.x - thickness / 2f, p.y - thickness / 2f, thickness, thickness), pixel);
        }
        GUI.color = Color.white;
    }

    private void DrawResistor(ResistorView resistor, bool isSelected)
    {
        Vector2 p = workspace.position + resistor.position;
        Rect rect = new Rect(p.x - ComponentWidth / 2f, p.y - ComponentHeight / 2f, ComponentWidth, ComponentHeight);
        GUI.color = isSelected ? new Color(0.25f, 0.55f, 0.85f) : new Color(0.20f, 0.23f, 0.28f);
        GUI.Box(rect, GUIContent.none);
        GUI.color = Color.white;
        GUI.Label(new Rect(rect.x + 5, rect.y + 5, rect.width - 10, 20), resistor.id);
        GUI.Label(new Rect(rect.x + 5, rect.y + 27, rect.width - 10, 22), resistor.resistance.ToString("0") + " Ω");
        DrawTerminalDot(rect.x - 5, p.y - 4, new Color(0.35f, 0.85f, 0.95f));
        DrawTerminalDot(rect.xMax - 5, p.y - 4, new Color(0.35f, 0.85f, 0.95f));
    }

    private void DrawPowerSupply(PowerSupplyView source, bool isSelected)
    {
        Vector2 p = workspace.position + source.position;
        Rect rect = new Rect(p.x - ComponentWidth / 2f, p.y - ComponentHeight / 2f, ComponentWidth, ComponentHeight);
        GUI.color = isSelected ? new Color(0.25f, 0.55f, 0.85f) : new Color(0.18f, 0.28f, 0.22f);
        GUI.Box(rect, GUIContent.none);
        GUI.color = Color.white;
        GUI.Label(new Rect(rect.x + 5, rect.y + 5, rect.width - 10, 20), source.id + " Power Supply");
        GUI.Label(new Rect(rect.x + 5, rect.y + 27, rect.width - 10, 22), source.voltage.ToString("0.###") + " V");
        GUI.Label(new Rect(rect.x - 1, p.y - 25, 24, 20), "−");
        GUI.Label(new Rect(rect.xMax - 23, p.y - 25, 24, 20), "+");
        DrawTerminalDot(rect.x - 5, p.y - 4, new Color(0.3f, 0.55f, 1f));
        DrawTerminalDot(rect.xMax - 5, p.y - 4, new Color(1f, 0.3f, 0.3f));
    }

    private void DrawTerminalDot(float x, float y, Color color)
    {
        GUI.color = color;
        GUI.DrawTexture(new Rect(x, y, 10, 8), pixel);
        GUI.color = Color.white;
    }

    private void DeleteSelection()
    {
        if (!string.IsNullOrEmpty(selectedComponentId))
        {
            string id = selectedComponentId;
            int removedResistor = resistors.RemoveAll(r => r.id == id);
            int removedSource = powerSupplies.RemoveAll(v => v.id == id);
            if (removedResistor > 0 || removedSource > 0)
            {
                wires.RemoveAll(w => w.fromId == id || w.toId == id);
                ClearSelection();
                status = "Component and connected wires deleted";
                return;
            }
        }

        if (selectedWire >= 0 && selectedWire < wires.Count)
        {
            wires.RemoveAt(selectedWire);
            ClearSelection();
            status = "Wire deleted";
            return;
        }

        status = "Select a component or wire first";
    }

    private void ClearSelection()
    {
        selectedComponentId = null;
        selectedWire = -1;
        dragging = false;
        parameterTextForId = null;
    }

    public CircuitModel BuildCircuitModel()
    {
        if (powerSupplies.Count == 0)
            throw new InvalidOperationException("Добавь блок питания кнопкой + Power Supply.");
        if (resistors.Count == 0)
            throw new InvalidOperationException("Добавь хотя бы один резистор.");

        var terminals = new List<string>();
        var connections = new List<(string from, string to)>();

        foreach (ResistorView resistor in resistors)
        {
            terminals.Add(resistor.id + ".L");
            terminals.Add(resistor.id + ".R");
        }

        foreach (PowerSupplyView source in powerSupplies)
        {
            terminals.Add(source.id + ".L"); // минус
            terminals.Add(source.id + ".R"); // плюс
        }

        foreach (WireView wire in wires)
        {
            connections.Add((
                wire.fromId + (wire.fromRight ? ".R" : ".L"),
                wire.toId + (wire.toRight ? ".R" : ".L")));
        }

        Dictionary<string, string> nodeMap = CircuitTopology.BuildNodeMap(terminals, connections);
        string groundRoot = nodeMap[powerSupplies[0].id + ".L"];
        var rootToNode = new Dictionary<string, string>();
        int nextNode = 1;

        foreach (string root in nodeMap.Values)
        {
            if (rootToNode.ContainsKey(root))
                continue;
            rootToNode[root] = root == groundRoot ? "GND" : "N" + nextNode++;
        }

        var circuit = new CircuitModel();

        foreach (PowerSupplyView source in powerSupplies)
        {
            string negativeRoot = nodeMap[source.id + ".L"];
            string positiveRoot = nodeMap[source.id + ".R"];
            if (negativeRoot == positiveRoot)
                throw new InvalidOperationException(source.id + ": плюс и минус соединены напрямую проводом.");

            circuit.AddComponent(new CircuitComponent(
                source.id,
                "VoltageSource",
                rootToNode[positiveRoot],
                rootToNode[negativeRoot],
                source.voltage));
        }

        foreach (ResistorView resistor in resistors)
        {
            string rootA = nodeMap[resistor.id + ".L"];
            string rootB = nodeMap[resistor.id + ".R"];
            circuit.AddComponent(new CircuitComponent(
                resistor.id,
                "Resistor",
                rootToNode[rootA],
                rootToNode[rootB],
                resistor.resistance));
        }

        return circuit;
    }
}

using System;
using System.Text;
using UnityEngine;

public class CircuitSimulationRunner : MonoBehaviour
{
    private string resultText = "Ready to simulate.";
    private Vector2 scrollPosition;

    private void OnGUI()
    {
        GUI.depth = -100;

        float panelWidth = 360f;
        float panelHeight = 260f;
        float margin = 20f;

        float x = Screen.width - panelWidth - margin;
        float y = Screen.height - panelHeight - margin;

        GUILayout.BeginArea(new Rect(x, y, panelWidth, panelHeight), GUI.skin.box);
        GUILayout.Label("ArduinoUnityLab | Simulation");

        if (GUILayout.Button("RUN CIRCUIT SIMULATION", GUILayout.Height(38f)))
            RunSimulation();

        GUILayout.Space(5f);
        scrollPosition = GUILayout.BeginScrollView(scrollPosition, GUILayout.Height(175f));
        GUILayout.Label(resultText);
        GUILayout.EndScrollView();
        GUILayout.EndArea();
    }

    private void RunSimulation()
    {
        try
        {
            CircuitEditorPrototype editor = FindAnyObjectByType<CircuitEditorPrototype>();
            if (editor == null)
                throw new Exception("CircuitEditorPrototype not found in scene.");

            CircuitModel circuit = editor.BuildCircuitModel();
            CircuitSolver solver = new CircuitSolver();
            CircuitSolver.Result result = solver.Solve(circuit);

            StringBuilder output = new StringBuilder();
            output.AppendLine("Simulation successful!");
            output.AppendLine();
            output.AppendLine("Node voltages:");

            foreach (var item in result.NodeVoltages)
                output.AppendLine(item.Key + ": " + item.Value.ToString("0.###") + " V");

            output.AppendLine();
            output.AppendLine("Component currents:");
            foreach (var item in result.ComponentCurrents)
                output.AppendLine(item.Key + ": " + (item.Value * 1000.0).ToString("0.###") + " mA");

            resultText = output.ToString();
            Debug.Log(resultText);
        }
        catch (Exception ex)
        {
            resultText = "Simulation error:\n" + ex.Message;
            Debug.LogError(resultText);
        }
    }
}

using System;

public static class MatrixSolver
{
    public static double[] Solve(double[,] matrix, double[] rhs)
    {
        int n = rhs.Length;
        if (matrix.GetLength(0) != n || matrix.GetLength(1) != n)
            throw new ArgumentException("Matrix dimensions do not match the right-hand side.");

        double[,] a = (double[,])matrix.Clone();
        double[] b = (double[])rhs.Clone();

        for (int col = 0; col < n; col++)
        {
            int pivot = col;
            for (int row = col + 1; row < n; row++)
                if (Math.Abs(a[row, col]) > Math.Abs(a[pivot, col]))
                    pivot = row;

            if (Math.Abs(a[pivot, col]) < 1e-12)
                throw new InvalidOperationException("Circuit cannot be solved: floating node or invalid connection.");

            if (pivot != col)
            {
                for (int j = col; j < n; j++)
                {
                    double temp = a[col, j];
                    a[col, j] = a[pivot, j];
                    a[pivot, j] = temp;
                }
                double tb = b[col];
                b[col] = b[pivot];
                b[pivot] = tb;
            }

            double divisor = a[col, col];
            for (int j = col; j < n; j++)
                a[col, j] /= divisor;
            b[col] /= divisor;

            for (int row = 0; row < n; row++)
            {
                if (row == col) continue;
                double factor = a[row, col];
                if (Math.Abs(factor) < 1e-15) continue;
                for (int j = col; j < n; j++)
                    a[row, j] -= factor * a[col, j];
                b[row] -= factor * b[col];
            }
        }
        return b;
    }
}

public static class OhmsLaw
{
    public static double Current(double voltage, double resistance) => voltage / resistance;
    public static double Voltage(double current, double resistance) => current * resistance;
    public static double Power(double voltage, double current) => voltage * current;
}

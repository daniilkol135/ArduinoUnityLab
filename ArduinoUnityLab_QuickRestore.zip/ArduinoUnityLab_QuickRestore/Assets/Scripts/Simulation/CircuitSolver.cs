using System;
using System.Collections.Generic;

public sealed class CircuitSolver
{
    public sealed class Result
    {
        public readonly Dictionary<string, double> NodeVoltages = new Dictionary<string, double>();
        public readonly Dictionary<string, double> ComponentCurrents = new Dictionary<string, double>();
    }

    public Result Solve(CircuitModel circuit)
    {
        if (circuit == null || circuit.components.Count == 0)
            throw new InvalidOperationException("Circuit is empty.");

        const string ground = "GND";
        var nodeSet = new HashSet<string>();
        int voltageSourceCount = 0;

        foreach (var c in circuit.components)
        {
            if (string.IsNullOrWhiteSpace(c.PinA) || string.IsNullOrWhiteSpace(c.PinB))
                throw new InvalidOperationException(c.Id + " has an unconnected pin.");
            nodeSet.Add(c.PinA);
            nodeSet.Add(c.PinB);
            if (c.Type == "VoltageSource") voltageSourceCount++;
            else if (c.Type != "Resistor")
                throw new InvalidOperationException("Unsupported component type: " + c.Type);
            if (c.Type == "Resistor" && c.Value <= 0)
                throw new InvalidOperationException(c.Id + " resistance must be positive.");
        }

        if (!nodeSet.Contains(ground))
            throw new InvalidOperationException("Circuit must have a GND node.");

        nodeSet.Remove(ground);
        var nodes = new List<string>(nodeSet);
        nodes.Sort(StringComparer.Ordinal);
        var nodeIndex = new Dictionary<string, int>();
        for (int i = 0; i < nodes.Count; i++) nodeIndex[nodes[i]] = i;

        var sources = new List<CircuitComponent>();
        foreach (var c in circuit.components)
            if (c.Type == "VoltageSource") sources.Add(c);

        int n = nodes.Count;
        int size = n + sources.Count;
        if (size == 0) throw new InvalidOperationException("Circuit has no solvable nodes.");

        var a = new double[size, size];
        var z = new double[size];

        foreach (var c in circuit.components)
        {
            if (c.Type != "Resistor") continue;
            int ia = c.PinA == ground ? -1 : nodeIndex[c.PinA];
            int ib = c.PinB == ground ? -1 : nodeIndex[c.PinB];
            double g = 1.0 / c.Value;

            if (ia >= 0) a[ia, ia] += g;
            if (ib >= 0) a[ib, ib] += g;
            if (ia >= 0 && ib >= 0)
            {
                a[ia, ib] -= g;
                a[ib, ia] -= g;
            }
        }

        for (int k = 0; k < sources.Count; k++)
        {
            var source = sources[k];
            int row = n + k;
            int ip = source.PinA == ground ? -1 : nodeIndex[source.PinA];
            int im = source.PinB == ground ? -1 : nodeIndex[source.PinB];

            if (ip >= 0) { a[ip, row] += 1; a[row, ip] += 1; }
            if (im >= 0) { a[im, row] -= 1; a[row, im] -= 1; }
            z[row] = source.Value;
        }

        double[] x = MatrixSolver.Solve(a, z);
        var result = new Result();
        result.NodeVoltages[ground] = 0.0;
        for (int i = 0; i < nodes.Count; i++) result.NodeVoltages[nodes[i]] = x[i];

        foreach (var c in circuit.components)
        {
            double va = result.NodeVoltages[c.PinA];
            double vb = result.NodeVoltages[c.PinB];
            if (c.Type == "Resistor")
                result.ComponentCurrents[c.Id] = (va - vb) / c.Value;
            else
            {
                int sourceIndex = sources.FindIndex(s => s.Id == c.Id);
                result.ComponentCurrents[c.Id] = x[n + sourceIndex];
            }
        }
        return result;
    }
}
